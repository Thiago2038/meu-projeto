// prova.js

// Mensagem no console com as cores da bandeira do Brasil
console.log("%cArquivo prova.js carregado!", "background: #008547; color: #FFD700; padding: 5px; border-radius: 3px; font-weight: bold;");

function iniciarProva() {
    const nomeAlunoInput = document.getElementById("nomeAluno");
    const nomeAluno = nomeAlunoInput.value;
    const saidaDiv = document.getElementById("saida");

    if (nomeAluno.trim() === "") {
        saidaDiv.innerHTML = "<p style='color: red;'>Por favor, digite seu nome completo.</p>";
        return;
    }

    saidaDiv.innerHTML = `<p style='color: #008547;'>Olá, <strong>${nomeAluno}</strong>! Iniciando a prova...</p>`;

    // Solicitar um número
    const numeroDigitado = prompt("Digite um número:");

    if (numeroDigitado !== null && !isNaN(numeroDigitado)) {
        const numero = parseInt(numeroDigitado);
        const resultadoParImpar = verificarParOuImpar(numero);
        saidaDiv.innerHTML += `<p>O número <strong>${numero}</strong> é <span style='color: ${resultadoParImpar === 'par' ? '#008547' : '#FFD700'};'>${resultadoParImpar}</span>.</p>`;
        contarAte(numero);
        exibirMediaFinal();
    } else {
        saidaDiv.innerHTML += "<p style='color: red;'>Você não digitou um número válido. A prova será finalizada.</p>";
    }
}

function verificarParOuImpar(numero) {
    if (numero % 2 === 0) {
        return "par";
    } else {
        return "ímpar";
    }
}

function contarAte(numero) {
    const saidaDiv = document.getElementById("saida");
    saidaDiv.innerHTML += `<p style='color: #008547;'>Contando até <strong>${numero}</strong>:</p>`;
    for (let i = 1; i <= numero; i++) {
        saidaDiv.innerHTML += `<span style='color: #FFD700;'>${i}</span><br>`;
    }
}

// Array com 5 notas fictícias
const notas = [7.5, 8, 6.2, 9, 5.8];

function mediaNotas() {
    let soma = 0;
    for (let i = 0; i < notas.length; i++) {
        soma += notas[i];
    }
    return soma / notas.length;
}

function aprovadoOuReprovado(media) {
    if (media >= 6) {
        return "Aprovado(a)";
    } else {
        return "Reprovado(a)";
    }
}

function exibirMediaFinal() {
    const saidaDiv = document.getElementById("saida");
    const media = mediaNotas();
    const resultadoFinal = aprovadoOuReprovado(media);
    saidaDiv.innerHTML += "<hr>";
    saidaDiv.innerHTML += `<p><strong>Média Final: <span style='color: #FFD700;'>${media.toFixed(2)}</span></strong></p>`;
    saidaDiv.innerHTML += `<p><strong>Resultado: <span style='color: ${resultadoFinal === 'Aprovado(a)' ? '#008547' : '#C71585'};'>${resultadoFinal}</span></strong></p>`;
}