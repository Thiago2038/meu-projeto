function iniciarProva() {
    const nome = document.getElementById("nomeAluno").value;
    const saida = document.getElementById("saida");
  
    saida.innerHTML = `<p>Bem-vindo(a), <strong>${nome}</strong>!</p>`;
  
    const numero = parseInt(prompt("Digite um número:"), 10);
  
    const parOuImpar = verificarParOuImpar(numero);
    saida.innerHTML += `<p>O número ${numero} é <strong>${parOuImpar}</strong>.</p>`;
  
    saida.innerHTML += "<p>Contando até o número informado:</p>";
    contarAte(numero);
  
    const media = mediaNotas();
    saida.innerHTML += `<p>A média das notas é: <strong>${media.toFixed(2)}</strong></p>`;
  
    const resultadoFinal = aprovadoOuReprovado(media);
    saida.innerHTML += `<p>Situação final: <strong>${resultadoFinal}</strong></p>`;
  }
  
  function verificarParOuImpar(numero) {
    return numero % 2 === 0 ? "par" : "ímpar";
  }
  
  function contarAte(numero) {
    const saida = document.getElementById("saida");
    for (let i = 1; i <= numero; i++) {
      saida.innerHTML += `<div>${i}</div>`;
    }
  }
  
  function mediaNotas() {
    const notas = [7.5, 8.0, 5.0, 6.5, 7.0];
    const soma = notas.reduce((total, nota) => total + nota, 0);
    return soma / notas.length;
  }
  
  function aprovadoOuReprovado(media) {
    return media >= 6 ? "Aprovado(a)" : "Reprovado(a)";
  }
  